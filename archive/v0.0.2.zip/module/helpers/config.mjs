export const ZCORPS = {};

// Define constants here, such as:
ZCORPS.foobar = {
  'bas': 'ZCORPS.bas',
  'bar': 'ZCORPS.bar'
};