### :zombie_man: Z-Corps pour Foundry VTT :zombie_woman:

Système Foundry VTT (Non-officiel) pour le jeu de rôle Z-Corps, édité par la société [7eme Cercle](https://www.7emecercle.com/7C_site/jeux-de-roles/z-corps/)

:warning: Le système est encore en version Alpha et non utilisable en "production" :warning:


:information_source: Fichier ["manifest"](https://raw.githubusercontent.com/piment/zcorps-foundryvtt/main/system.json) pour l'installation directe.

:gear: Serveur [Discord](https://discord.gg/rbsvujHH) pour participer au développement.

Développé sur Foundry VTT V9. Non testé sur les versions précédentes

version 0.0.1

Basée sur le Boilerplate de ["asacolips"](https://github.com/asacolips)

Autheur: Romain MURA 